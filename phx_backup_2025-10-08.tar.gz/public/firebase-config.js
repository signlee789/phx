export const firebaseConfig = {
  apiKey: "AIzaSyCJBq5qDjdC0c2yEn7farZhESl9fw09v80",
  authDomain: "phxlast-34481.firebaseapp.com",
  databaseURL: "https://phxlast-34481-default-rtdb.firebaseio.com",
  projectId: "phxlast-34481",
  storageBucket: "phxlast-34481.appspot.com",
  messagingSenderId: "357757049798",
  appId: "1:357757049798:web:faf77cdb46fa18ccac30c7",
  measurementId: "G-N9Q7KKDNDM"
};